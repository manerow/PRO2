var searchData=
[
  ['cabezera',['cabezera',['../class_dades.html#a955f38a3b1456da5fe2d4235c86f669b',1,'Dades']]],
  ['calculadora',['Calculadora',['../class_calculadora.html#ae2c9648667ced66101bbe97523c2cd78',1,'Calculadora']]],
  ['calcular_5fexpresio',['calcular_expresio',['../class_calculadora.html#a367c1e3feb59c639fa90ae21b49f5fb7',1,'Calculadora']]],
  ['comparar',['comparar',['../class_dades.html#a1f296bd02e88a6b52225cf3af96becc7',1,'Dades']]],
  ['construir',['construir',['../class_dades.html#a8586da9b049efcf16fde41604a2ec66c',1,'Dades']]],
  ['consultar_5ffun',['consultar_fun',['../class_funcions.html#af50a6abd1708d5b738f87dce074335c3',1,'Funcions']]],
  ['consultar_5fparams',['consultar_params',['../class_funcions.html#a0b18bba536e4807652e9f9feaad3e360',1,'Funcions']]],
  ['consultar_5fstr',['consultar_str',['../class_dades.html#aab8ebb80972e2717c0311601a1a2c3ef',1,'Dades']]],
  ['consultar_5fvar',['consultar_var',['../class_variables.html#abef5592f84a9359a0540c17595c18114',1,'Variables']]],
  ['crear_5flist',['crear_list',['../class_dades.html#afb813fe1ef4fbec1ede585e26ce9832c',1,'Dades']]],
  ['crear_5fllista_5fbuida',['crear_llista_buida',['../class_dades.html#aa25bdb47518395b91869aa772b1f29ad',1,'Dades']]],
  ['cua',['cua',['../class_dades.html#ad7c364711db1b07ccdac6fe918e0fd7d',1,'Dades']]]
];
