var searchData=
[
  ['var',['var',['../class_variables.html#ab265fd214a8ab38a3f30da7302b8bc6b',1,'Variables']]]
];
