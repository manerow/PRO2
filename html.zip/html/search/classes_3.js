var searchData=
[
  ['variables',['Variables',['../class_variables.html',1,'']]]
];
