var searchData=
[
  ['funcions',['funcions',['../class_funcions.html#a76811b045f099f1dacd61fa9a2fbd133',1,'Funcions']]]
];
