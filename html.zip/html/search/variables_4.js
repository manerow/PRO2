var searchData=
[
  ['integer',['integer',['../class_dades.html#ae9407662d539f0a4f749a36fff4fa51b',1,'Dades']]]
];
