var searchData=
[
  ['par_5ff',['par_f',['../struct_funcions_1_1fun.html#a9c9d494e906bcda27165072894d5f1da',1,'Funcions::fun']]]
];
