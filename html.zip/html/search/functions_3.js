var searchData=
[
  ['es_5fatom',['es_atom',['../class_calculadora.html#a704b1a2c1995d8396f0349522fd808e6',1,'Calculadora']]],
  ['es_5fbool_5fvalid',['es_bool_valid',['../class_calculadora.html#aeb58e1866b8e37c0b0f5995444d6a1c9',1,'Calculadora']]],
  ['es_5fdefinit',['es_definit',['../class_dades.html#a6c0dd8dec7ae05b9a45d9a2bf3af8f83',1,'Dades']]],
  ['es_5fint',['es_int',['../class_dades.html#aad0411ae092d10cf5f295f533dabc9df',1,'Dades']]],
  ['es_5fllista',['es_llista',['../class_dades.html#abfc942f3d7424e88faecff5a9407aee5',1,'Dades']]],
  ['escriure',['escriure',['../class_dades.html#a7f14ca1f85469f3f891eabd603add222',1,'Dades']]],
  ['escriure_5ffuncions',['escriure_funcions',['../class_funcions.html#a0902105f64dbaeb0b0d1559cc08ba26c',1,'Funcions']]],
  ['escriure_5fvariables',['escriure_variables',['../class_variables.html#a3c659dd1d277732eaebb3015c7bed96a',1,'Variables']]],
  ['existeix_5ffun',['existeix_fun',['../class_funcions.html#a95a775fbdd9bda1df52061fd9ddbd4bc',1,'Funcions']]],
  ['existeix_5fvar',['existeix_var',['../class_variables.html#ac8aec429edd8786708ef01567a296436',1,'Variables']]],
  ['ext1',['ext1',['../class_calculadora.html#a9ca72cf3ca7b9967c1c7de590464d22a',1,'Calculadora']]]
];
