var searchData=
[
  ['_7ecalculadora',['~Calculadora',['../class_calculadora.html#a3792c0dc9d2737942272b87072fd1434',1,'Calculadora']]],
  ['_7edades',['~Dades',['../class_dades.html#a45cd6e61eb5e0e5e5e65a4609dda6796',1,'Dades']]],
  ['_7efuncions',['~Funcions',['../class_funcions.html#a520dfd2abd322aa783d7cf9654306816',1,'Funcions']]],
  ['_7evariables',['~Variables',['../class_variables.html#a95870fd79ba168e4742a77b64003ae3b',1,'Variables']]]
];
