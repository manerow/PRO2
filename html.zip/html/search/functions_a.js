var searchData=
[
  ['sumar',['sumar',['../class_dades.html#a62dc0b0386cbb3688307af7ef7b066cf',1,'Dades']]]
];
