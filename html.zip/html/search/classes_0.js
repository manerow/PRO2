var searchData=
[
  ['calculadora',['Calculadora',['../class_calculadora.html',1,'']]]
];
