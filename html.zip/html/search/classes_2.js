var searchData=
[
  ['fun',['fun',['../struct_funcions_1_1fun.html',1,'Funcions']]],
  ['funcions',['Funcions',['../class_funcions.html',1,'']]]
];
