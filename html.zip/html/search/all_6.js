var searchData=
[
  ['llegir',['llegir',['../class_calculadora.html#aed08af8d730271ab595b6f2e556b99cc',1,'Calculadora']]],
  ['llista',['llista',['../class_dades.html#aa154634dd63068a7ec683f2fc5255bc8',1,'Dades']]]
];
