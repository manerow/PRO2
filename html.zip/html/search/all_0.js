var searchData=
[
  ['acabat',['acabat',['../class_calculadora.html#afbaebf138b449c6eb3153deef9988bca',1,'Calculadora']]],
  ['afegir_5ffun',['afegir_fun',['../class_funcions.html#a846610dd8b58ad49fadbeed6ca12c61f',1,'Funcions']]],
  ['afegir_5fvar',['afegir_var',['../class_variables.html#aae227f1672f5bd0b3dc7cb7b1f084ce0',1,'Variables']]]
];
