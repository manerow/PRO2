var searchData=
[
  ['operar',['operar',['../class_calculadora.html#a0a54bebfd8322d79ef862ccf2e3d1403',1,'Calculadora']]]
];
