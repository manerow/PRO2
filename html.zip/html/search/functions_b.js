var searchData=
[
  ['variables',['Variables',['../class_variables.html#a5610f6bf2bcfb696eb23961de493d563',1,'Variables']]]
];
