var searchData=
[
  ['igualar',['igualar',['../class_dades.html#a3b2e91bc283631eb995863bb7df0cc64',1,'Dades']]],
  ['indefinit',['indefinit',['../class_dades.html#ab2437583badf53c16cf0bca565929858',1,'Dades']]],
  ['invertir',['invertir',['../class_dades.html#a681affbd08e15821faade382ac6d45af',1,'Dades']]]
];
