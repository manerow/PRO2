var searchData=
[
  ['negar',['negar',['../class_dades.html#a4949cfd7ada1da7d0f9ab5d702193fbe',1,'Dades']]],
  ['normalitzar',['normalitzar',['../class_calculadora.html#a79a5c8a24a65406d991faeca5e263d15',1,'Calculadora']]]
];
