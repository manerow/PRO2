var searchData=
[
  ['fer_5fand',['fer_and',['../class_dades.html#a3f48edab6f61305c056535ff083e4d0e',1,'Dades']]],
  ['fer_5fif',['fer_if',['../class_dades.html#a8ec2adbad1e02f4746bbadafd010768d',1,'Dades']]],
  ['fer_5for',['fer_or',['../class_dades.html#a1fbb7e38b11dfff3c355c3aa702207bb',1,'Dades']]],
  ['fi',['fi',['../class_calculadora.html#a1ef1f41d9a0dcecf91fd5b076e0dd414',1,'Calculadora']]],
  ['fun',['fun',['../struct_funcions_1_1fun.html',1,'Funcions']]],
  ['funcions',['Funcions',['../class_funcions.html',1,'Funcions'],['../class_funcions.html#a76811b045f099f1dacd61fa9a2fbd133',1,'Funcions::funcions()'],['../class_funcions.html#a5b67dc7c832f27295c200b52c9b92310',1,'Funcions::Funcions()']]],
  ['funcions_2ecc',['Funcions.cc',['../_funcions_8cc.html',1,'']]],
  ['funcions_2ehh',['Funcions.hh',['../_funcions_8hh.html',1,'']]]
];
