var searchData=
[
  ['llista',['llista',['../class_dades.html#aa154634dd63068a7ec683f2fc5255bc8',1,'Dades']]]
];
