var searchData=
[
  ['negar',['negar',['../class_dades.html#a4949cfd7ada1da7d0f9ab5d702193fbe',1,'Dades']]],
  ['normalitzar',['normalitzar',['../class_calculadora.html#a79a5c8a24a65406d991faeca5e263d15',1,'Calculadora']]],
  ['num',['num',['../struct_funcions_1_1fun.html#aa6dbb4f0b258f38a49c96b884257c10a',1,'Funcions::fun']]]
];
