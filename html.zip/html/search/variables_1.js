var searchData=
[
  ['dada',['dada',['../class_dades.html#a9f4d9ab556313b6cce6d25f3c265f0a1',1,'Dades']]],
  ['definit',['definit',['../class_dades.html#a89322711d805aa21a042707466b8b04e',1,'Dades']]]
];
