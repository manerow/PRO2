var searchData=
[
  ['dades_2ecc',['Dades.cc',['../_dades_8cc.html',1,'']]],
  ['dades_2ehh',['Dades.hh',['../_dades_8hh.html',1,'']]]
];
